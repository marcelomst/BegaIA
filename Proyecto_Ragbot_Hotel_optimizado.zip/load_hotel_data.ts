import { DataAPIClient } from "@datastax/astra-db-ts";
import OpenAI from "openai";
import fs from "fs";
import pdf from "pdf-parse";
import path from "path";
import dotenv from "dotenv";
dotenv.config();

const ASTRA_DB_APPLICATION_TOKEN: string = process.env.ASTRA_DB_APPLICATION_TOKEN!;
const ASTRA_DB_COLLECTION_NAME: string = "begaia";
const OPENAI_API_KEY: string = process.env.OPENAI_API_KEY!;
const PDF_FILE_PATH = path.resolve("app/lib/hotel_demo.pdf");

const client = new DataAPIClient(ASTRA_DB_APPLICATION_TOKEN);
const db = client.db("https://bd3a9cf5-660d-4c90-ad58-39a03af1fed2-us-east-2.apps.astra.datastax.com");
const collection = db.collection(ASTRA_DB_COLLECTION_NAME);
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

async function generateEmbeddings(text: string): Promise<number[]> {
  const response = await openai.embeddings.create({
    model: "text-embedding-ada-002",
    input: text,
  });
  const embedding = response.data[0].embedding;
  return reduceEmbedding(embedding, 1000); // Reducir el embedding antes de guardarlo
}

function reduceEmbedding(embedding: number[], targetSize: number = 1000): number[] {
  const originalSize = embedding.length;
  if (originalSize <= targetSize) {
    return embedding.slice(0, targetSize);
  }

  const factor = originalSize / targetSize;
  return Array.from({ length: targetSize }, (_, i) => {
    const start = Math.floor(i * factor);
    const end = Math.floor((i + 1) * factor);
    return embedding.slice(start, end).reduce((acc, val) => acc + val, 0) / (end - start || 1);
  });
}

async function loadHotelData(): Promise<void> {
  try {
    const pdfBuffer: Buffer = fs.readFileSync(PDF_FILE_PATH);
    const pdfData = await pdf(pdfBuffer);
    const hotelData: string = pdfData.text;

    const embedding: number[] = await generateEmbeddings(hotelData);

    const document = {
      text: hotelData,
      embedding,
      metadata: {
        source: "Hotel Demo Punta del Este",
        createdAt: new Date(),
      },
    };

    await collection.insertOne(document);
  } catch (error) {
    console.error("Error cargando datos en Astra DB:", error);
  }
}

loadHotelData();
