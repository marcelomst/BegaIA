// import { Collection} from "@datastax/astra-db-ts";
import { DataAPIClient } from "@datastax/astra-db-ts";

const ASTRA_DB_APPLICATION_TOKEN = process.env.ASTRA_DB_APPLICATION_TOKEN!;
const ASTRA_DB_COLLECTION_NAME = "begaia"; // Cambia esto por el nombre real

export async function searchAstraDB(query: string) {
  try {
    // Obtener la colección desde Astra DB
    const client = new DataAPIClient(ASTRA_DB_APPLICATION_TOKEN);
    const db = client.db('https://bd3a9cf5-660d-4c90-ad58-39a03af1fed2-us-east-2.apps.astra.datastax.com');
    const collections: { name: string }[] = await db.listCollections();


    const collection = db.collection(ASTRA_DB_COLLECTION_NAME);


    if (!collection) {
      throw new Error(`No se encontró la colección: ${ASTRA_DB_COLLECTION_NAME}`);
    }

        // 🔍 Ver qué se está enviando como `query`
    // Generar embedding de la consulta con OpenAI
    const response = await fetch("https://api.openai.com/v1/embeddings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "text-embedding-ada-002",
        input: query,
      }),
    });

    const { data } = await response.json();
    const queryVector = data[0].embedding;

    // 🔹 Mostrar el vector generado
    // Perform a vector search
    const cursor = await collection.find({}, {
      sort: { $vector: queryVector },
      limit: 5,
      includeSimilarity: true,
    });

    for await (const doc of cursor) {
    }

    const results = await cursor.toArray();
    return results ;
  } catch (error) {
    console.error("Error en searchAstraDB:", error);
    throw error;
  }
}
