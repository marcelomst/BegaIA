import { ChatOpenAI } from "@langchain/openai";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { Document } from "langchain/document";
import { OpenAIEmbeddings } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";
import { createRetrievalChain } from "langchain/chains/retrieval";
import { searchAstraDB } from "@/app/lib/astra";
interface AstraDocument {
  _id: string;
  text: string;
  metadata?: { source?: string };
}

export async function POST(req: Request) {
  const { query } = await req.json();

  // Buscar en Astra DB
  // const results = await searchAstraDB(query);
  const resultsArray = await searchAstraDB(query); // Ahora ya es un array
//  Convertir cursor a array
  console.log("Resultados AstraDB:", resultsArray);

  console.log("📄 Estructura real de los resultados:", JSON.stringify(resultsArray, null, 2));

  // Convertir los resultados en documentos de LangChain
  const documents = resultsArray.map(
    (doc: { text: string }) => new Document({ pageContent: doc.text })
  );
  // Si no hay documentos, devolver mensaje de error
  if (documents.length === 0) {
    return Response.json({ answer: "No se encontraron documentos relacionados." });
  }
  

  // Crear embeddings
  const embeddings = new OpenAIEmbeddings({
    openAIApiKey: process.env.OPENAI_API_KEY,
  });

  // Crear un VectorStore en memoria con embeddings
  const vectorStore = await MemoryVectorStore.fromDocuments(
    documents,
    embeddings
  );

  // Crear un retriever a partir del vector store
  const retriever = vectorStore.asRetriever();

  // Configurar el modelo de IA
  const llm = new ChatOpenAI({
    modelName: "gpt-4o",
    openAIApiKey: process.env.OPENAI_API_KEY,
  });

  // Definir el prompt para la respuesta del LLM
  const prompt = ChatPromptTemplate.fromTemplate(
    `Responde la pregunta del usuario: {input} basado en el siguiente contexto: {context}`
  );

  // Crear la cadena de combinación de documentos (contexto para el LLM)
  const combineDocsChain = await createStuffDocumentsChain({
    llm,
    prompt,
  });

  // Crear la nueva cadena de recuperación y respuesta
  const retrievalChain = await createRetrievalChain({
    combineDocsChain,
    retriever,
  });

  // Ejecutar la consulta con la nueva cadena
  const response = await retrievalChain.invoke({ input: query });

  return Response.json({ answer: response.text || response.answer });
}
